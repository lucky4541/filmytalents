import type http from 'http';
import { Server } from 'socket.io';
import { eq } from 'drizzle-orm';
import { env } from './config/env';
import { verifyAccess } from './lib/jwt';
import { logger } from './lib/logger';
import { db, schema } from './db';

/**
 * Live updates over Socket.IO (chat messages, new notifications).
 * The app connects with: io(API_URL, { auth: { token: accessToken } }).
 * Events sent to the member: "message", "notification", "read".
 */
let io: Server | null = null;

export function attachRealtime(server: http.Server) {
  const origins = env.CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean);
  io = new Server(server, { cors: { origin: origins, credentials: true }, path: '/socket.io' });
  io.use(async (socket, next) => {
    try {
      const token = String(socket.handshake.auth?.token ?? '');
      const p = verifyAccess(token);
      if (p.kind !== 'member') return next(new Error('unauthorized'));
      const u = await db.query.users.findFirst({ where: eq(schema.users.id, p.sub), columns: { id: true, status: true } });
      if (!u || u.status !== 'ACTIVE') return next(new Error('unauthorized'));
      socket.data.userId = u.id;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });
  io.on('connection', (socket) => {
    void socket.join(`user:${socket.data.userId}`);
    socket.on('typing', (d: { to?: string; conversationId?: string }) => {
      if (d?.to && d.conversationId) io?.to(`user:${d.to}`).emit('typing', { conversationId: d.conversationId, from: socket.data.userId });
    });
  });
  logger.info('Realtime (Socket.IO) ready');
  return io;
}

/** Sends an event to every open tab/app of a member. Does nothing in tests or before start. */
export function emitToUser(userId: string, event: string, payload: unknown) {
  io?.to(`user:${userId}`).emit(event, payload);
}
